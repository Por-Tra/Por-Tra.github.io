"""
Lance le client `clie.py` en lui fournissant automatiquement l'IP et le port présents dans `config.ini`.
Il démarre un process Python et envoie en stdin deux lignes : host, port.
"""
import subprocess
import configparser
import os
import sys

HERE = os.path.dirname(__file__)
conf_path = os.path.join(HERE, 'config.ini')

config = configparser.ConfigParser()
config.read(conf_path)

host = config.get('network', 'host', fallback='127.0.0.1')
port = config.get('network', 'port', fallback='1234')

cmd = [sys.executable, os.path.join(HERE, 'clie.py')]
print(f"Lancement du client vers {host}:{port}...")

# On envoie l'IP et le port en stdin (ils seront lus par clie.py au démarrage)
p = subprocess.Popen(cmd, stdin=subprocess.PIPE, cwd=HERE)
try:
    inp = f"{host}\n{port}\n"
    p.communicate(input=inp.encode('utf-8'))
except KeyboardInterrupt:
    try:
        p.terminate()
    except Exception:
        pass
