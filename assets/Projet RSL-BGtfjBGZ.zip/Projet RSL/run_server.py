"""
Lance le serveur `serv sans fonction.py` dans un process séparé.
Lit l'adresse/port dans `config.ini` mais note : le serveur par défaut écoute le port 1234
"""
import subprocess
import configparser
import os

HERE = os.path.dirname(__file__)
conf_path = os.path.join(HERE, 'config.ini')

config = configparser.ConfigParser()
config.read(conf_path)

host = config.get('network', 'host', fallback='127.0.0.1')
port = config.get('network', 'port', fallback='1234')

print(f"Démarrage du serveur (fichier: serv sans fonction.py).\nAssumer port={port} (si différent, modifier le code du serveur ou config).")

# Lancer le serveur dans un processus séparé
proc = subprocess.Popen(["python", os.path.join(HERE, 'serv sans fonction.py')], cwd=HERE)
print(f"Serveur démarré (PID {proc.pid}). Ctrl+C pour arrêter.")

try:
    proc.wait()
except KeyboardInterrupt:
    print('Arrêt demandé, terminaison du serveur...')
    proc.terminate()
    proc.wait()
