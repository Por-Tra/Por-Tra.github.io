import socket
import threading
import time
import sys
import ast
import tkinter as tk
from tkinter import simpledialog, scrolledtext

# ----------------------------

class File:
    def __init__(self):
        self.contenu = []
        self._lock = threading.Lock()

    def est_vide(self):
        """
        verifi si self.contenu est vide
        """
        with self._lock:
            return self.contenu == []

    def enfiler(self, elt):
        """
        ajoute elt au tableau au débu
        """
        with self._lock:
            self.contenu.insert(0, elt)

    def defiler(self):
        """
        retire le dernier element du tableau et le retourne
        """
        with self._lock:
            return self.contenu.pop(-1)

    def queue(self):
        '''
        renvoie la queue de la liste soit le dernier élément ajouté à celle-ci
        '''
        with self._lock:
            return self.contenu[0]

    def __str__(self):
        """
        renvoie une chaine de charactère de
        """

        return str(self.contenu)

class Client:

    def __init__(self, ip_connexion, port):
        """

        """

        #print('[info]> Client lancé')

        self.nom = ''
        self.ip = socket.gethostbyname(socket.gethostname())

        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.client.connect((ip_connexion, port))

        print('[info]> Client connecté')

        self.messagerie = File()

        self.gestion_message()

    def recuperation(self):
        """
        demande au serveur une liste chainé de tout les éléments de la file serveur afin de
        récupérer les ancines message en cas de déconnexion
        """
        #print('[info]> récupération lancé')

        self.client.send('!recup!'.encode('utf-8'))

        recup = self.client.recv(2 ** 20).decode('utf-8')

        if recup == '&':    # cas vide
            pass
        else:
            tab = recup.split('|')
            tab.pop(-1)

            for element in tab:
                self.messagerie.enfiler(ast.literal_eval(element))

        # Afficher l'historique dans l'interface si elle existe, sinon en console
        while not self.messagerie.est_vide():
            dernier = self.messagerie.defiler()
            try:
                if getattr(self, 'root', None) and getattr(self, '_display_message', None):
                    # Poster dans la zone de texte via le thread principal
                    try:
                        self._display_message(dernier[1][0], dernier[0])
                    except Exception:
                        print(f"{dernier[1][0]}: {dernier[0]}")
                else:
                    print(f"{dernier[1][0]}: {dernier[0]}")
            except Exception:
                # en cas d'élément mal formé, ignorer
                continue

    def demande_nouveau_message(self):
        """
        demande le dernier message au serveur afin de pouvoir récupérer les messages des autres utilisateurs
        """
        #print('[info]> demande de nouveau message lancé')

        time.sleep(0.5)
        self.client.send('zF$vI-pv=Us_FHm'.encode('utf-8'))

        reponse_serveur = self.client.recv(2 ** 20).decode('utf-8')

        if reponse_serveur == '&':
            pass
        else:

            reponse_serveur = ast.literal_eval(reponse_serveur)
            if reponse_serveur[1][1] != self.ip:    # cas où le message n'est pas le mien, on compare les IP
                self.messagerie.enfiler(reponse_serveur)

    def demande_pseudo(self):
        """
        demande un pseudo à l'utilisateur pour pouvoir crée une identité à notre client
        """

        # Demander le pseudo via GUI si possible, sinon via input
        nom = None
        if getattr(self, 'root', None):
            while not nom or nom.strip() == "":
                nom = simpledialog.askstring("Pseudo", "Entrer votre nom d'utilisateur:", parent=self.root)
        else:
            while not nom or nom.strip() == "":
                nom = input("entrer votre nom d'utilisateur: ")

        nom = nom.strip()
        self.client.send(nom.encode('utf-8'))
        reponse = self.client.recv(2 ** 20).decode('utf-8')

        if reponse != '!reçu!':     # un nom est deja enregistrer
            self.nom = reponse
        else:   # c'est la première connexion du client
            self.nom = nom

        time.sleep(0.5)
        # si interface graphique, on met à jour le titre
        if getattr(self, 'root', None):
            try:
                self.root.title(f"Messagerie - {self.nom}")
            except Exception:
                pass

    def gestion_message(self):
        """
        gère le système d'envoie et deréception de message
        """

        #print('[info]> gestion message lancé')

        # Construire l'interface graphique (Tkinter)
        self.root = tk.Tk()
        # titre temporaire; sera mis à jour après demande du pseudo
        self.root.title(f"Messagerie - {self.nom or 'Client'}")

        # Zone d'affichage des messages
        self.text_area = scrolledtext.ScrolledText(self.root, wrap=tk.WORD, state=tk.DISABLED, height=20, width=60)
        self.text_area.pack(padx=10, pady=10)

        # Zone d'entrée et bouton envoyer
        frame = tk.Frame(self.root)
        frame.pack(padx=10, pady=(0,10), fill=tk.X)

        self.entry = tk.Entry(frame)
        self.entry.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=(0,8))
        self.entry.focus()

        send_btn = tk.Button(frame, text="Envoyer", command=lambda: self._on_send())
        send_btn.pack(side=tk.RIGHT)
        self.entry.bind('<Return>', lambda e: self._on_send())

        # gestion fermeture
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

        # demander pseudo via GUI
        self.demande_pseudo()

        # récupérer historique et afficher
        self.recuperation()
        # afficher les anciens messages (si any) dans the text_area
        try:
            while not self.messagerie.est_vide():
                dernier = self.messagerie.defiler()
                self._display_message(dernier[1][0], dernier[0])
        except Exception:
            pass

        # démarrer le thread récepteur
        self._receiver_running = True

        def _receiver_loop():
            while self._receiver_running:
                try:
                    data = self.client.recv(4096).decode('utf-8')
                    if not data:
                        break

                    if data == '!reçu!':
                        continue

                    if data.startswith('BCAST:'):
                        payload_str = data[len('BCAST:'):]
                        try:
                            payload = ast.literal_eval(payload_str)
                            if payload[1][1] != self.ip:
                                self.root.after(0, self._display_message, payload[1][0], payload[0])
                        except Exception:
                            continue
                    else:
                        try:
                            payload = ast.literal_eval(data)
                            if isinstance(payload, list) and payload[1][1] != self.ip:
                                self.root.after(0, self._display_message, payload[1][0], payload[0])
                        except Exception:
                            continue

                except Exception:
                    break

        recv_thread = threading.Thread(target=_receiver_loop, daemon=True)
        recv_thread.start()

        # lancer la boucle graphique (bloquante)
        self.root.mainloop()

    def _display_message(self, nom, message):
        try:
            self.text_area.configure(state=tk.NORMAL)
            self.text_area.insert(tk.END, f"{nom}: {message}\n")
            self.text_area.see(tk.END)
            self.text_area.configure(state=tk.DISABLED)
        except Exception:
            pass

    def _on_send(self):
        try:
            my_message = self.entry.get().strip()
        except Exception:
            return
        if not my_message or '#' in my_message or '&' in my_message or '{' in my_message or '|' in my_message:
            return

        try:
            self.client.send(my_message.encode('utf-8'))
            # Afficher localement
            self._display_message(self.nom, my_message)
            self.entry.delete(0, tk.END)
        except Exception:
            try:
                self._on_close()
            except Exception:
                pass

    def _on_close(self):
        # Arrêter le thread de réception, fermer la socket et fermer la fenêtre
        self._receiver_running = False
        try:
            self.client.close()
        except Exception:
            pass
        try:
            if getattr(self, 'root', None):
                self.root.destroy()
        except Exception:
            pass

ip = input("[info]> Entrer l'IP du serveur: ")
port = int(input('[info]> Entrer le port du serveur: '))



Client(ip, port)
