"""
Démarre le serveur puis N clients (définis dans config.ini -> clients).
Utile pour tests locaux. Les clients sont lancés en tant que processus séparés.
"""
import subprocess
import configparser
import os
import sys
import time

HERE = os.path.dirname(__file__)
conf_path = os.path.join(HERE, 'config.ini')

config = configparser.ConfigParser()
config.read(conf_path)

host = config.get('network', 'host', fallback='127.0.0.1')
port = config.get('network', 'port', fallback='1234')
clients = config.getint('network', 'clients', fallback=2)

print(f"Démarrage du serveur...")
server_proc = subprocess.Popen([sys.executable, os.path.join(HERE, 'serv sans fonction.py')], cwd=HERE)
print(f"Serveur PID={server_proc.pid}")

# attendre un peu que le serveur démarre
time.sleep(1.0)

client_procs = []
for i in range(clients):
    print(f"Lancement client {i+1} vers {host}:{port} ...")
    p = subprocess.Popen([sys.executable, os.path.join(HERE, 'clie.py')], stdin=subprocess.PIPE, cwd=HERE)
    inp = f"{host}\n{port}\n"
    # écrire l'IP/port puis laisser le client s'ouvrir (GUI demandera le pseudo)
    try:
        p.stdin.write(inp.encode('utf-8'))
        p.stdin.flush()
    except Exception:
        pass
    client_procs.append(p)
    time.sleep(0.5)

print('Tous les processus lancés. CTRL-C pour arrêter tous.')
try:
    while True:
        time.sleep(1.0)
except KeyboardInterrupt:
    print('Arrêt : terminaison des processus...')
    for p in client_procs:
        try:
            p.terminate()
        except Exception:
            pass
    try:
        server_proc.terminate()
    except Exception:
        pass
