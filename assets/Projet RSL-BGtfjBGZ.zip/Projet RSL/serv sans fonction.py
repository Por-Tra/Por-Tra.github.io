import socket
import threading

# ----------------------------
# Classe File pour stocker les messages
# ----------------------------

class File:
    def __init__(self):
        self.contenu = []
        self._lock = threading.Lock()

    def est_vide(self):
        with self._lock:
            return self.contenu == []

    def enfiler(self, elt):
        with self._lock:
            self.contenu.insert(0, elt)

    def defiler(self):
        with self._lock:
            return self.contenu.pop(-1)

    def queue(self):
        with self._lock:
            return self.contenu[0]

    def copier(self):
        copie = File()
        with self._lock:
            copie.contenu = self.contenu[:]
        return copie

    def __str__(self):
        return str(self.contenu)


# ----------------------------
# Serveur principal
# ----------------------------

class Serveur:
    def __init__(self, port):
        self.liste_clients = []  # (nom, (ip, port), socket)
        self._clients_lock = threading.Lock()
        self.messagerie = File()

        ip_locale = socket.gethostbyname(socket.gethostname())
        print(f"[info]> Lancement du serveur sur {ip_locale}:{port}")

        self.serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.serveur.bind((ip_locale, port))
        self.serveur.listen(10)

        print("[info]> Serveur en écoute...")

    def lancer(self):
        while True:
            client_socket, client_address = self.serveur.accept()
            print(f"[info]> Connexion de {client_address}")
            thread = threading.Thread(target=self.gerer_client, args=(client_socket, client_address))
            thread.start()

    def gerer_client(self, client_socket, client_address):
        try:
            # Demande pseudo
            nom_client = client_socket.recv(1024).decode("utf-8")
            client_existant = next((c for c in self.liste_clients if c[1] == client_address), None)

            if client_existant:
                client_socket.send(client_existant[0].encode('utf-8'))
                nom_client = client_existant[0]
                print(f"[info]> Client reconnu : {nom_client}")
            else:
                with self._clients_lock:
                    self.liste_clients.append((nom_client, client_address, client_socket))
                client_socket.send('!reçu!'.encode('utf-8'))
                print(f"[info]> Nouveau client enregistré : {nom_client}")

            # Boucle de communication
            while True:
                data = client_socket.recv(4096).decode("utf-8")
                if not data:
                    break

                if data == "!recup!":
                    self.envoyer_messagerie_complete(client_socket)
                elif data == "zF$vI-pv=Us_FHm":
                    self.envoyer_dernier_message(client_socket)
                else:
                    # Stocker seulement l'IP dans les métadonnées du message pour
                    # être compatible avec le client qui attend (nom, ip)
                    try:
                        ip_only = client_address[0]
                    except Exception:
                        ip_only = str(client_address)

                    msg_obj = [data, (nom_client, ip_only)]
                    # Enfiler dans la messagerie serveur
                    self.messagerie.enfiler(msg_obj)

                    # Envoyer un accusé d'envoi au client émetteur
                    try:
                        client_socket.send("!reçu!".encode("utf-8"))
                    except Exception:
                        # si on ne peut pas envoyer l'ack, continuer
                        pass

                    # Diffuser le message aux autres clients immédiatement
                    with self._clients_lock:
                        for c in list(self.liste_clients):
                            try:
                                c_nom, c_addr, c_sock = c
                                # ne pas renvoyer au client émetteur
                                if c_addr == client_address:
                                    continue
                                # Envoi du broadcast avec un préfixe pour identification
                                try:
                                    c_sock.send(("BCAST:" + str(msg_obj)).encode('utf-8'))
                                except Exception:
                                    # si l'envoi échoue, on ferme et on retire le client
                                    try:
                                        c_sock.close()
                                    except Exception:
                                        pass
                                    self.liste_clients = [x for x in self.liste_clients if x[1] != c_addr]
                            except Exception:
                                # ignorer les entrées mal formées
                                continue

                    print(f"[msg]> {nom_client}: {data}")

        except (ConnectionResetError, BrokenPipeError):
            print(f"[info]> Connexion perdue avec {client_address}")
        finally:
            client_socket.close()
            self.liste_clients = [c for c in self.liste_clients if c[1] != client_address]
            print(f"[info]> {client_address} déconnecté")

    def envoyer_messagerie_complete(self, client_socket):
        messagerie_str = ""
        tmp = self.messagerie.copier()

        if tmp.est_vide():
            client_socket.send("&".encode("utf-8"))
        else:
            while not tmp.est_vide():
                msg = tmp.defiler()
                messagerie_str += str(msg) + "|"
            client_socket.send(messagerie_str.encode("utf-8"))

    def envoyer_dernier_message(self, client_socket):
        if self.messagerie.est_vide():
            client_socket.send("&".encode("utf-8"))
        else:
            client_socket.send(str(self.messagerie.queue()).encode("utf-8"))


# ----------------------------
# Point d'entrée
# ----------------------------

if __name__ == "__main__":
    PORT = 1234
    serveur = Serveur(PORT)
    serveur.lancer()
