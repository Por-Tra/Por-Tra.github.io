Projet RSL - Messagerie simple (serveur/client)

But
---
Petit projet de messagerie réseau en Python (socket + threads). Le serveur diffuse les messages entrants aux autres clients. Le client dispose d'une interface Tkinter simple (zone d'affichage + champ d'envoi).

Fichiers principaux
------------------
- `serv sans fonction.py` : serveur TCP qui écoute les connexions, stocke l'historique et broadcast les messages.
- `clie.py` : client GUI (Tkinter). On entre l'IP et le port au démarrage, puis le pseudo via une boîte de dialogue.

Configuration
-------------
Le fichier `config.ini` contient les paramètres réseau par défaut :

- `host` : IP du serveur (par défaut `127.0.0.1`)
- `port` : port utilisé (par défaut `1234`)
- `clients` : nombre de clients à lancer pour un test automatique (utilisé par `run_all.py`)

Lanceur et scripts utiles
------------------------
- `run_server.py` : lance le serveur (lance `serv sans fonction.py` dans un process séparé).
- `run_client.py` : lance un client (start `clie.py`) en lui fournissant automatiquement l'IP et le port présents dans `config.ini`.
- `run_all.py` : lance le serveur puis N clients (selon `config.ini`). Utile pour tests locaux.
- `start_server.bat` / `start_clients.bat` : scripts Windows pour lancer rapidement.

Prérequis
---------
- Python 3.8+ (Tkinter doit être installé avec Python). Aucun paquet externe requis.

Utilisation (Windows cmd.exe)
----------------------------
1) Lancer le serveur seul :

```cmd
python "serv sans fonction.py"
```

ou via le lanceur qui lit `config.ini` :

```cmd
python run_server.py
```

2) Lancer un client :

```cmd
python run_client.py
```

Cela ouvrira la fenêtre Tkinter du client ; le pseudo est demandé via une boîte de dialogue.

3) Lancer le serveur + 2 clients (test) :

```cmd
python run_all.py
```

Remarques et améliorations possibles
-----------------------------------
- Migrer la sérialisation des messages vers JSON (actuellement le code utilise `str(list)` + `ast.literal_eval`). JSON est plus sûr et interopérable.
- Ajouter gestion d'authentification, TLS (ssl) pour sécuriser les échanges.
- Remplacer la logique par `asyncio` pour une montée en charge.
- Pour une interface utilisateur plus avancée, utiliser `prompt-toolkit` ou un framework GUI plus riche.

Support
-------
Si tu veux que j'intègre la migration JSON ou que j'ajoute une option pour choisir entre GUI et CLI au lancement, dis-le et je l'ajouterai.
