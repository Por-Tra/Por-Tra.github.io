# Système de Gestion des Évaluations de Stages

## Description générale

Ce projet est une application web développée pour l'IUT Université Clermont Auvergne, destinée à la gestion complète des évaluations de fin d'année pour les étudiants BUT2 et BUT3 du département informatique. Le système gère les soutenances de stage, portfolio et anglais, ainsi que l'ensemble du processus d'évaluation depuis la saisie des notes jusqu'à leur diffusion au secrétariat.

## Architecture du projet

### Structure générale
```
projet_sql/
├── back/                    # Interface d'administration (Back Office)
├── front/                   # Interface enseignants (Front Office)
├── SUJET + REQUETES DE TABLES/  # Base de données et documentation
├── index.html               # Page de connexion principale
├── action.php               # Traitement de l'authentification
├── db.php                   # Configuration de base de données
├── stylee.css              # Feuille de style principale
└── assets/                  # Images et ressources
```

## Architecture technique

### Base de données
- **Système** : MariaDB 10.4.32
- **Fichier principal** : `evaluationstages (6).sql`
- **Structure** : 15+ tables relationnelles avec contraintes d'intégrité
- **Tables principales** :
  - `EtudiantsBUT2ou3` : Gestion des étudiants
  - `EvalStage`, `EvalPortfolio`, `EvalAnglais` : Évaluations spécialisées
  - `EvalRapport`, `EvalSoutenance` : Évaluations complémentaires
  - `ModelesGrilleEval` : Modèles de grilles d'évaluation

### Technologies utilisées
- **Backend** : PHP 8.0.30 avec PDO
- **Frontend** : HTML5, CSS3, JavaScript
- **Base de données** : MariaDB/MySQL
- **Serveur local** : XAMPP
- **Architecture** : MVC (Model-View-Controller)

## Description des modules

### Back Office (`/back/`)

Interface d'administration destinée aux gestionnaires (secrétaires, responsables des stages, direction des études).

#### Navigation générale
- **`mainAdministration.php`** : Tableau de bord principal affichant tous les étudiants BUT2 et BUT3 avec leurs soutenances respectives. Interface centrale permettant la gestion globale des étudiants et l'accès aux différents modules.
- **`navbar.php`** : Barre de navigation principale du back office avec liens vers tous les modules
- **`navbarAdmin.php`** : Navigation spécialisée pour les fonctions d'administration avancées
- **`navbarGrilles.php`** : Navigation dédiée à la gestion des grilles d'évaluation
- **`deconnexion.php`** : Script de déconnexion sécurisée avec destruction de session

#### Partie 3.1 - Visualisation des tâches enseignants
**Dossier** : `Partie3.1/`

- **`3_1_natan.php`** : Interface complète de visualisation des grilles à remplir par les enseignants
  - Utilise la vue SQL `Vue_Taches_Enseignants` pour agréger les données
  - Intégration DataTables pour tri, filtrage et recherche avancée
  - Contrôles de masquage/affichage des colonnes par type de données
  - Export des données en format imprimable
  - Affichage en temps réel des statuts d'avancement (SAISIE, BLOQUEE, REMONTEE)

#### Partie 3.2 - Gestion des soutenances
**Dossier** : `Partie3.2/`

**Gestion principale** :
- **`AddSoutenance.php`** : Formulaire de création de nouvelles soutenances
  - Support des soutenances de stage (BUT2/BUT3) et d'anglais (BUT3 uniquement)
  - Sélection dynamique des enseignants tuteurs et seconds enseignants
  - Gestion automatique des salles disponibles selon les créneaux
  - Création automatique des grilles d'évaluation associées (portfolio, rapport, soutenance)
  - Validation des contraintes temporelles et de disponibilité

- **`EditSoutenance.php`** : Interface de modification des soutenances existantes
  - Édition des dates, heures, salles et enseignants assignés
  - Préservation de l'intégrité des données liées (grilles d'évaluation)
  - Historique des modifications pour traçabilité

- **`DeleteSoutenance.php`** : Suppression sécurisée des soutenances
  - Vérification des dépendances avant suppression
  - Gestion en cascade des grilles d'évaluation liées
  - Confirmation utilisateur et log des suppressions

**Services AJAX** :
- **`get_infos.php`** : Service de récupération dynamique des informations étudiants
  - Données contextuelles (nom, prénom, entreprise, maître de stage)
  - Vérification du niveau BUT2/BUT3 pour adaptation de l'interface
  
- **`get_salles.php`** : Service de gestion des disponibilités de salles
  - Vérification des conflits de réservation en temps réel
  - Liste des salles disponibles selon les créneaux horaires
  - Informations détaillées sur l'équipement des salles

- **`SaveEnseignant.php`** : Sauvegarde des affectations d'enseignants
  - Gestion des tuteurs et seconds enseignants
  - Vérification des charges d'enseignement
  - Validation des compétences selon le type de soutenance

#### Partie 3.3 - Remontée et gestion des notes
**Dossier** : `Partie3.3/`

Architecture MVC complète avec séparation stricte des responsabilités :

**Contrôleur principal** :
- **`index.php`** : Interface centrale de gestion des notes avec 4 sections principales
  - Section 1 : Remontée des notes BLOQUEE → REMONTEE (boutons individuels et global)
  - Section 2 : Relance des enseignants en retard (avec envoi d'emails automatique)
  - Section 3 : Réautorisation de saisie REMONTEE → SAISIE (gestion des erreurs)
  - Section 4 : Export et consultation des notes remontées (CSV et affichage)

**Couche service** (`services/`) :
- **`EtudiantService.php`** : Service de gestion des données étudiants
  - `getEtudiantsBUT2()` : Étudiants BUT2 prêts à la remontée (stage + portfolio BLOQUEE)
  - `getEtudiantsBUT3()` : Étudiants BUT3 prêts à la remontée (stage + portfolio + anglais BLOQUEE)
  - `getEtudiantsNonBloques()` : Étudiants avec soutenances passées mais statut SAISIE
  - `getEtudiantRemonter2A()` / `getEtudiantRemonter3A()` : Étudiants avec notes déjà remontées
  - `getListeEleveRemonter2A()` / `getListeEleveRemonter3A()` : Données complètes pour export
  - `getMailEtudiant()` / `getMailEnseignantTuteur()` : Récupération des contacts

- **`NoteService.php`** : Service de gestion des changements de statuts
  - `changerStatutVersRemontee()` : Transition BLOQUEE → REMONTEE avec vérifications
  - `changerStatutVersSaisie()` : Retour REMONTEE → SAISIE pour corrections
  - `changerStatutEtudiant()` : Gestion globale des statuts d'un étudiant
  - Synchronisation automatique des statuts rapport/soutenance avec stage

- **`MailService.php`** : Service d'envoi de notifications
  - `envoyerMailRelance()` : Notifications de relance aux enseignants en retard
  - `envoyerMailRemontee()` : Confirmations de remontée de notes
  - Intégration PHPMailer pour envois sécurisés
  - Templates HTML personnalisables

- **`ExportService.php`** : Service de génération des exports
  - `exporterNotesBUT2()` / `exporterNotesBUT3()` : Génération CSV par niveau
  - `genererRapportComplet()` : Rapport statistique global
  - Formatage des données selon les standards secrétariat

**Configuration** (`config/`) :
- **`database.php`** : Singleton de connexion PDO avec gestion d'erreurs et pool de connexions

**Utilitaires** (`utils/`) :
- **`MessageManager.php`** : Gestionnaire centralisé des messages utilisateur
  - Gestion des messages de succès, erreur, avertissement
  - Persistance des messages entre redirections
  - Formatage HTML automatique

#### Partie 3.4 - Diffusion des résultats
**Dossier** : `Partie3.4/`

**Interfaces principales** :
- **`index.php`** : Tableau de bord des statistiques de diffusion
  - Compteurs en temps réel des étudiants candidats/diffusés
  - Graphiques de progression par niveau (BUT2/BUT3)
  - Alertes sur les anomalies de diffusion

- **`partie_3_4_simple.php`** : Interface principale de gestion de la diffusion
  - Sélection des étudiants éligibles à la diffusion
  - Validation en lot ou individuelle des diffusions
  - Historique des diffusions avec horodatage
  - Gestion des templates d'emails aux étudiants

- **`consultation_simple.php`** : Interface de consultation des résultats individuels
  - Recherche d'étudiant par nom, prénom ou identifiant
  - Affichage détaillé de toutes les évaluations
  - Calcul automatique des moyennes et mentions
  - Génération de relevés de notes individuels

- **`consultation_resultats.php`** : Vue d'ensemble statistique des résultats
  - Moyennes par promotion et par type d'évaluation
  - Répartition des mentions par niveau
  - Comparaisons inter-annuelles
  - Export des statistiques globales

**Validation et contrôles** :
- **`verification_diffusion.php`** : Module de validation avant diffusion
  - Vérification de l'intégrité des notes (bornes, cohérence)
  - Contrôle des statuts d'évaluation obligatoires
  - Validation des données étudiants (contact, entreprise)
  - Génération de rapports d'anomalies

**Configuration** :
- **`config.php`** : Configuration spécifique du module diffusion
  - Paramètres d'emails (SMTP, templates)
  - Seuils de validation et alertes
  - Chemins d'export et archivage

**Journalisation** (`logs/`) :
- **`actions.log`** : Journal des actions administratives avec horodatage et utilisateur
- **`emails.log`** : Trace de tous les emails envoyés (destinataires, statuts, erreurs)

#### Partie 3.5 - Gestion des grilles d'évaluation
**Dossier** : `Partie3.5/`

**Sous-module 3.5.2** (`Partie3.5.2/`) - Interface graphique des grilles :

**Affichage et navigation** :
- **`Affichage.php`** : Interface principale de visualisation des grilles d'évaluation
  - Rendu dynamique des grilles selon leur modèle
  - Affichage des critères par sections
  - Calcul en temps réel des notes partielles et totales
  - Mode lecture seule et mode édition selon les droits

- **`Bouton.php`** : Bibliothèque de composants d'interface réutilisables
  - Boutons d'action standardisés (ajouter, modifier, supprimer)
  - Confirmations JavaScript intégrées
  - Styles cohérents avec la charte graphique

- **`Grille.php`** : Moteur de gestion logique des grilles
  - Chargement dynamique des modèles de grilles
  - Validation des structures et contraintes
  - Calculs de notes selon les pondérations définies

- **`simulation.php`** : Mode simulation pour tests et formation
  - Environnement de test sans impact sur les données réelles
  - Génération de données d'exemple
  - Formation des utilisateurs aux nouvelles grilles

**Gestion des critères** (`Critere/`) :
- **`ajouterCritere.php`** : Interface de création de nouveaux critères d'évaluation
  - Définition du nom, description et pondération
  - Association aux sections de grilles
  - Validation des contraintes métier (somme des pondérations)

- **`modifierCritere.php`** : Modification des critères existants
  - Édition des propriétés sans impact sur les évaluations en cours
  - Historique des modifications pour traçabilité
  - Validation des impacts sur les calculs de notes

- **`supprimerCritere.php`** : Suppression sécurisée des critères
  - Vérification des dépendances (grilles utilisant le critère)
  - Archivage des critères plutôt que suppression physique
  - Migration automatique des évaluations existantes

**Gestion des grilles** (`Grille/`) :
- **`ajouterGrille.php`** : Création de nouvelles grilles d'évaluation
  - Assistant de création étape par étape
  - Sélection du type (STAGE, PORTFOLIO, ANGLAIS, RAPPORT, SOUTENANCE)
  - Configuration des sections et critères
  - Définition des notes maximales et pondérations

- **`copierGrille.php`** : Duplication de grilles existantes
  - Copie complète avec adaptation à une nouvelle année
  - Possibilité de modification des critères lors de la copie
  - Préservation des liens vers les sections et critères

- **`modifierGrille.php`** : Modification des grilles en cours d'utilisation
  - Édition contrôlée selon l'état d'avancement des évaluations
  - Versioning pour maintenir la cohérence historique
  - Impact analysis sur les évaluations existantes

- **`supprimerGrille.php`** : Suppression des grilles obsolètes
  - Vérification de non-utilisation avant suppression
  - Archivage automatique des grilles historiques
  - Nettoyage des références dans les autres tables

**Gestion des sections** (`Section/`) :
- **`ajouterSection.php`** : Création de sections thématiques dans les grilles
  - Organisation logique des critères par domaines
  - Définition des pondérations entre sections
  - Templates de sections prédéfinies par type d'évaluation

- **`modifierSection.php`** : Modification des sections existantes
  - Réorganisation des critères au sein des sections
  - Ajustement des pondérations avec recalcul automatique
  - Prévisualisation des impacts sur les notes

- **`supprimerSection.php`** : Suppression des sections inutilisées
  - Migration automatique des critères vers d'autres sections
  - Validation de l'intégrité des grilles après suppression
  - Logs des modifications pour audit

**Sous-module 3.5.3** (`Partie3.5.3/`) - Gestion administrative avancée :
- **`index.php`** : Interface de pilotage des grilles d'évaluation
  - Vue d'ensemble de toutes les grilles par année
  - Statistiques d'utilisation et performance
  - Outils de maintenance et optimisation

- **`gestion.php`** : Outils d'administration des données
  - Import/export de grilles entre années
  - Synchronisation avec les référentiels externes
  - Utilitaires de nettoyage et réorganisation

- **`config.php`** : Configuration spécifique aux grilles
- **`db.php`** : Connexion dédiée avec optimisations pour les grilles

#### Partie 3.6 - Statistiques et vues d'ensemble
**Dossier** : `Partie3.6/`

**Interfaces de reporting** :
- **`index.php`** : Tableau de bord des statistiques générales
  - Vues multiples avec filtrage par année et enseignant
  - Fiches étudiants complètes avec toutes les évaluations
  - Moyennes par promotion avec comparaisons historiques
  - Moyennes par enseignant pour évaluation des pratiques
  - Alertes sur les soutenances et portfolios non validés
  - Répartition par départements et entreprises

- **`init.php`** : Script d'initialisation du module statistiques
  - Création des vues SQL optimisées pour les rapports
  - Calcul des agrégations et mise en cache
  - Validation de la cohérence des données

- **`sql_runner.php`** : Moteur d'exécution de requêtes SQL avancées
  - Interface pour requêtes personnalisées
  - Gestion des requêtes complexes multi-tables
  - Export des résultats en multiple formats

**Configuration et documentation** :
- **`config.php`** : Paramètres spécifiques aux statistiques
- **`db.php`** : Connexion optimisée pour les requêtes de reporting
- **`Code DB.txt`** : Documentation complète de la structure de base
  - Schéma détaillé des 15+ tables principales
  - Contraintes d'intégrité et relations
  - Index et optimisations de performance
  - Exemples de données et cas d'usage

- **`CodeView3.6.txt`** : Définitions des vues SQL métier
  - `v_fiche_etudiant` : Vue complète des données étudiants
  - `v_moyenne_promotion` : Calculs des moyennes par promotion
  - `v_moyennes_par_enseignant` : Performance par enseignant
  - `v_alertes_soutenances_non_validees` : Alertes automatiques
  - `v_repartition_departements` : Statistiques par département

### Front Office (`/front/`)

Interface destinée aux enseignants pour la saisie des évaluations.

#### Navigation générale
- `front.php` : Page d'accueil du front office
- `front_office.php` : Interface principale enseignant
- `headerFront.php` : En-tête commune
- `front.htaccess` : Configuration Apache

#### Front Partie A - Gestion des soutenances enseignants
**Dossier** : `Front_PartieA/`

Architecture MVC pour la gestion des soutenances :

**Configuration** (`config/`) :
- `database.php` : Connexion à la base de données

**Modèles** (`app/models/`) :
- `Soutenance.php` : Modèle de données pour les soutenances

**Contrôleurs** (`app/controllers/`) :
- `SoutenanceController.php` : Logique métier des soutenances

**Vues** (`app/views/`) :
- `pageA.php` : Interface de consultation des soutenances assignées

**Point d'entrée** (`public/`) :
- `index.php` : Routeur principal du module

**Documentation** :
- `bdd.txt` : Exemples de données de test
- `texte.txt` : Documentation des règles métier
- `deconnexion.php` : Gestion de la déconnexion

#### Page B - Évaluation par grilles
**Dossier** : `PAGEB/`

Système de saisie des évaluations par critères :
- `index.php` : Interface principale d'évaluation
- `grilleController.php` : Contrôleur de gestion des grilles
- `grilleModel.php` : Modèle de données des grilles
- `grilleView.php` : Affichage des grilles d'évaluation
- `functions.php` : Fonctions utilitaires
- `config.php` : Configuration du module

#### Page C - Interface d'évaluation avancée
**Dossier** : `Page C/`

Interface complète d'évaluation multi-critères :
- `index.php` : Interface principale avec gestion des différents types d'évaluation
- `update.php` : Traitement des mises à jour de notes
- `config/db.php` : Configuration de base de données

**Types d'évaluation supportés** :
- Portfolio : Évaluation des compétences acquises
- Anglais : Évaluation linguistique (BUT3 uniquement)
- Soutenance : Évaluation de la présentation orale
- Rapport : Évaluation du document écrit
- Stage : Évaluation globale du stage

### Fichiers racine

- **`index.html`** : Page de connexion principale avec authentification
- **`action.php`** : Traitement des données de connexion et redirection
- **`db.php`** : Configuration globale de la base de données
- **`hash_passwords.php`** : Utilitaire de hashage des mots de passe
- **`stylee.css`** : Feuille de style principale du projet

### Documentation et données (`/SUJET + REQUETES DE TABLES/`)

- **`evaluationstages (6).sql`** : Fichier principal de la base de données
  - Structure complète des 15+ tables
  - Données d'exemple et de test
  - Contraintes d'intégrité et relations
  - Indexes et optimisations

## Règles métier

### Étudiants et niveaux
- **BUT2** : 2 soutenances (Stage + Portfolio)
- **BUT3** : 3 soutenances (Stage + Portfolio + Anglais)
- **BUT3 Alternance** : Mêmes critères d'évaluation

### Processus d'évaluation
1. **SAISIE** : Enseignant saisit les notes
2. **BLOQUEE** : Notes validées, prêtes pour remontée
3. **REMONTEE** : Notes transmises au secrétariat
4. **DIFFUSEE** : Résultats communiqués aux étudiants

### Contraintes de remontée
- Toutes les grilles d'un étudiant doivent être BLOQUEE pour permettre la remontée
- Les grilles de rapport et soutenance suivent automatiquement le statut de la grille de stage
- Aucune modification possible une fois le statut REMONTEE atteint (sauf réautorisation)

### Jurys d'évaluation
- **Anglais** : 1 enseignant (BUT3 uniquement)
- **Stage/Portfolio** : 2 enseignants (tuteur + second enseignant)

## Installation et déploiement

### Prérequis
- XAMPP avec PHP 8.0+ et MariaDB 10.4+
- Navigateur web moderne
- Accès en écriture sur le répertoire du projet

### Installation
1. Placer le projet dans `C:\xampp\htdocs\projet_sql`
2. Importer `evaluationstages (6).sql` dans phpMyAdmin
3. Configurer les paramètres de connexion dans `db.php`
4. Démarrer Apache et MySQL via XAMPP
5. Accéder à `http://localhost/projet_sql`

### Configuration
- Modifier les paramètres de base de données dans les fichiers de configuration
- Ajuster les chemins si nécessaire selon l'environnement
- Vérifier les permissions d'écriture pour les logs et exports

## Sécurité

- Authentification par login/mot de passe
- Hashage des mots de passe avec `password_hash()`
- Requêtes préparées (PDO) pour éviter l'injection SQL
- Validation des données d'entrée
- Gestion des sessions sécurisée
- Séparation des accès Front Office / Back Office

## Maintenance et évolution

### Logs
- Actions administratives dans `Partie3.4/logs/actions.log`
- Emails envoyés dans `Partie3.4/logs/emails.log`

### Extensibilité
- Architecture modulaire permettant l'ajout de nouvelles fonctionnalités
- Séparation claire des couches (présentation, logique, données)
- API potentielle via les contrôleurs existants

### Sauvegarde
- Exporter régulièrement la base de données
- Sauvegarder les fichiers de logs
- Archiver les exports de notes

## Support et documentation

- Documentation technique dans les commentaires du code
- Règles métier documentées dans `Front_PartieA/texte.txt`
- Structure de base dans `Partie3.6/Code DB.txt`
- Vues SQL dans `Partie3.6/CodeView3.6.txt`

Pour toute question technique, consulter les fichiers de documentation inclus dans chaque module ou analyser les commentaires dans le code source.