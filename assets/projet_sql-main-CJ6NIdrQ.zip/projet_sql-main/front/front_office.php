<?php
session_start(); // Démarrer la session => permet de sécuriser les pages
if (!isset($_SESSION['role'])) {
    header("Location: ../index.html");
    exit();
}
// Connexion à la base de données
require_once '../db.php';
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Front Office - Gestion des évaluations</title>
    <link rel="stylesheet" href="../stylee.css">
</head>

<body>
    <div class="containerHAUT">
          <a href="deconnexion.php" class="deconnexion-btn">Déconnexion</a>
        <h1>Bienvenue, <span id="professor-name"></span></h1>
    </div>
    
    <div class="containerBAS">
        <h2>Liste des étudiants associés</h2>
        <table class="student-table">
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>Email</th>
                    <th>Grilles d'évaluation</th>
                </tr>
            </thead>
            <tbody id="student-list">
                <!-- Les étudiants seront ajoutés ici dynamiquement -->
            </tbody>
        </table>
    </div>
    <script>
        // Récupérer le nom du professeur depuis la session (via PHP)
        document.addEventListener('DOMContentLoaded', function() {
            fetch('../front.php?action=getProfessorName')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('professor-name').textContent = data.professorName;
                });

            // Récupérer la liste des étudiants associés
            fetch('../front.php?action=getStudents')
                .then(response => response.json())
                .then(data => {
                    const studentList = document.getElementById('student-list');
                    data.students.forEach(student => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${student.nom}</td>
                            <td>${student.prenom}</td>
                            <td>${student.mail}</td>
                            <td>
                                <a href="grille_portfolio.html?student=${student.id}">Portfolio</a><br>
                                <a href="grille_soutenance.html?student=${student.id}">Soutenance</a><br>
                                <a href="grille_rapport.html?student=${student.id}">Rapport</a>
                            </td>`;
                        studentList.appendChild(row);
                    });
                });
        });
    </script>
</body>
</html>
