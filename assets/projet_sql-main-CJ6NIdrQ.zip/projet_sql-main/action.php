<?php
// Activer l'affichage des erreurs
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connexion à la base de données
require 'db.php';

// Récupération des données du formulaire
$identifiant = $_POST['identifiant'];
$motdepasse = $_POST['motdepasse'];

// Vérifier d'abord dans la table Enseignants
$sql = "SELECT IdEnseignant, nom, prenom, mail, mdp FROM Enseignants WHERE mail = :identifiant";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':identifiant', $identifiant);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if ($row && password_verify($motdepasse, $row['mdp'])) {
    session_start();
    $_SESSION['identifiant'] = $row['mail'];
    $_SESSION['professeur_id'] = $row['IdEnseignant'];
    header("Location: front/Front_PartieA/public/index.php");
    exit();
}

// Si non trouvé dans Enseignants, vérifier dans UtilisateursBackOffice
$sql = "SELECT identifiant, nom, prenom, mail, mdp FROM UtilisateursBackOffice WHERE mail = :identifiant";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':identifiant', $identifiant);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if ($row && password_verify($motdepasse, $row['mdp'])) {
    session_start();
    $_SESSION['identifiant'] = $row['mail'];
    header("Location: back/mainAdministration.php");
    exit();
} else {
    // Redirection avec un paramètre d'erreur
    header("Location: index.html?error=1");
}
exit();
?>
