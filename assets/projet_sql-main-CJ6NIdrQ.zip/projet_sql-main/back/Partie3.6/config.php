<?php


define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'evalstages');


define('SQL_SCHEMA_FILE', __DIR__ . DIRECTORY_SEPARATOR . 'Code DB.txt');
define('SQL_VIEWS_FILE', __DIR__ . DIRECTORY_SEPARATOR . 'CodeView3.6.txt');


