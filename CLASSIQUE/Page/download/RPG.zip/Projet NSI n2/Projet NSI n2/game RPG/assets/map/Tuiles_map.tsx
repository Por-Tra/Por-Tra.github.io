<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Tuiles map" tilewidth="32" tileheight="32" tilecount="1820" columns="52">
 <image source="Plaine2.png" trans="000000" width="1674" height="1120"/>
 <tile id="597">
  <animation>
   <frame tileid="145" duration="400"/>
   <frame tileid="301" duration="400"/>
   <frame tileid="457" duration="400"/>
   <frame tileid="301" duration="400"/>
  </animation>
 </tile>
 <tile id="598">
  <animation>
   <frame tileid="613" duration="400"/>
   <frame tileid="665" duration="400"/>
   <frame tileid="717" duration="400"/>
   <frame tileid="769" duration="400"/>
   <frame tileid="821" duration="400"/>
   <frame tileid="873" duration="400"/>
   <frame tileid="925" duration="400"/>
  </animation>
 </tile>
 <tile id="1189">
  <animation>
   <frame tileid="145" duration="400"/>
   <frame tileid="301" duration="400"/>
   <frame tileid="457" duration="400"/>
  </animation>
 </tile>
</tileset>
