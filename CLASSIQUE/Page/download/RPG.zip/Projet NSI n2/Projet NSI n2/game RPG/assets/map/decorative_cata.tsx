<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="decorative cata" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="decorative.png" trans="000000" width="256" height="256"/>
</tileset>
