<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="cavern_ruins" tilewidth="32" tileheight="32" tilecount="384" columns="24">
 <image source="cavern_ruins.png" trans="000000" width="768" height="512"/>
</tileset>
