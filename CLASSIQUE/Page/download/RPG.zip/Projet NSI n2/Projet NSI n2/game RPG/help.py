def help_game():
    """
    Modules externes utilisés :

        dataclasses :
            Module qui simplifie la création de classes de données en réduisant
            la quantité de code que vous devez écrire, tout en fournissant des fonctionnalités
            utiles pour la manipulation des données. C'est particulièrement utile lorsque vous
            travaillez avec des classes dont le but principal est de stocker des données.
        pytmx :
            Bibliothèque qui facilite l'intégration des cartes créées avec Tiled dans des projets
            de jeux en fournissant des outils pour analyser et utiliser les informations contenues
            dans les fichiers TMX. Cela permet aux développeurs de jeux de gérer plus facilement
            les aspects visuels et interactifs de leurs cartes.
        pyscroll :
            Module qui simplifie le processus de gestion et d'affichage
            des cartes dans les jeux Pygame, fournissant ainsi une solution plus
            efficace et moins sujette aux erreurs pour la mise en œuvre du défilement de cartes.

    ----------------------------------------------------------------------------------------------------

    ----------------------------------------------------------------------------------------------------

    main.py :

    Fichier principal qui lance le jeu en entier, cela comprend les fichiers :
    main_choice.py
    game.py
    Map.py
    player.py
    animation.py

    C'est la boucle principale du jeu, la boucle est limitée à 60 tours par seconde

        -import :
            main_choice.py

    ----------------------------------------------------------------------------------------------------

    main_choice.py :

    Fichier où est lancée la première interface du jeu

        -import :
            game.py

    Fichier qui exécute la première interface du jeu qui comporte 4 boutons :
        Chevalier : le personnage choisi dans le jeu sera le Chevalier
        Mage : le personnage choisi dans le jeu sera le Mage
        Archer : le personnage choisi dans le jeu sera l'Archer
        Quitter : le jeu est alors fermé

    class :
        Menu() :
            Classe principale du fichier qui exécute les commandes des boutons lorsque l'utilisateur clique dessus
            ou qui met à jour la couleur des boutons lorsque l'utilisateur les survole

            def update(self) :
                Met à jour l'interface
                :return :

        MenuBouton() :
            Crée les boutons en fonction de leur taille choisie et crée aussi le texte de ceux-ci (c'est dans le constructeur)
            ainsi que les commandes associées avec (dans le constructeur aussi)

            dessiner(self, couleur) :
                Dessine les boutons
                :param couleur : tuple
                :return :

            executerCommande(self) :
                Appel de la commande du bouton

        Application() :
            Classe qui construit les commandes des boutons et qui exécute le lancement du jeu dès lors qu'un
            bouton est cliqué par l'utilisateur

            initialiser(self) :

            menu(self) :
                Affichage du menu

            quitter(self) :
                Quitter l'interface

            chevalier(self) :
                Permet de choisir le personnage Chevalier

            mage(self) :
                Permet de choisir le personnage Mage

            archer(self) :
                Permet de choisir le personnage Archer

            lancement(self, name) :
                Lance le jeu

            update(self) :
                Mise à jour

    ----------------------------------------------------------------------------------------------------

    game.py :

    Fichier du lancement du jeu

        -import :
            Map.py
            dialog.py

    class :
        Game() :
            Constructeur du jeu où l'on retrouve les touches pour jouer au jeu :
                z : avancer
                s : reculer
                q : aller à gauche
                d : aller à droite
                r : courir
                w : marcher
                flèche haut : attaque haut
                flèche bas : attaque bas
                flèche droite : attaque droite
                flèche gauche : attaque gauche

            Met à jour tout les 60/1000 secondes, met en place le joueur et dessine la map

            handle_input(self) :
                Déplacements du joueur et autre

            update(self) :
                Met à jour la map
                :return :

            run(self) :
                Pour garder la fenêtre ouverte ou la fermer
                Exécuter le code du jeu

    ----------------------------------------------------------------------------------------------------

    Map.py

    Gestionnaire de carte et les collisions

        -import :
            dataclasses
            pytmx
            pyscroll
            player.py
            dialog.py

    class :
        Portal() :
            Regroupe un ensemble de données pour créer un chemin qui permettra au joueur lorsqu'il est en contact
            d'être téléporté sur le monde choisi :
            from_world : str      quel monde
            origin_point : str    sur quel point
            target_world : str    sur quel monde
            teleport_point : str  point de téléportation

            Fonctionne avec dataclasses

    ---------------------------

        Map() :
            Regroupe l'ensemble de données sur une carte : mur, entité et autres

            name : str  nom du monde
            walls : list[pygame.Rect]   tous les murs avec comme type collisions
            group : pyscroll.PyscrollGroup
            tmx_data : pytmx.TiledMap    la carte Tiled
            portals : list[Portal]       les portails
            npc : list[NPC]              entité
            monster : list[Monster]      entité

            Fonctionne avec dataclasses

    ---------------------------

        MapManager() :
            Construit les maps et tout ce qu'il y a à l'intérieur grâce aux classes précédentes
            ainsi que les entités qui sont mises sur leur point d'apparition

            check_collisions(self) :
                Regarde si le joueur entre en contact avec un rectangle spécifique et fait donc une action avec
                :return :

            teleport_player(self, name_point) :
                Place le joueur à son spawn
                :param name_point : str
                :return :

            register_map(self, name, portals=[], npcs=[], monster=[], boss=[]) :
                Enregistrer les maps et tout ce qu'il y a dedans
                :param name : str
                :return :

            get_map(self) :
                Récupère le nom de la map
                :return : self.maps[self.current_map] : str

            get_group(self) :
                Récupère un groupe de pyscroll
                :return : list objet de pyscroll

            get_walls(self) :
                Récupère les murs de la map
                :return : list objet de pyscroll

            get_object(self, name) :
                Récupère un objet avec son nom comme un spawn ou un portail (plus précisément les coordonnées)
                :return : objet pyscroll

            teleport_NPC(self) :
                Téléporte le NPC dans son spawn
                :return :

            draw(self) :
                Dessiner la carte
                :return :

            update(self) :
                Met à jour les méthodes
                :return :

    ----------------------------------------------------------------------------------------------------

    player.py

    Crée les entités : les monstres, les NPC et le joueur
        -import :
            pygame
            animation.py

    class :
        Entity() :
            Crée les entités, leur box, leur image ainsi que leur déplacement

            save_location(self) :
                Sauvegarde les coordonnées de l'emplacement de l'entité

            move_up(self) :
                Mouvement vers le haut

            move_down(self) :
                Mouvement vers le bas

            move_right(self) :
                Mouvement vers la droite

            move_left(self) :
                Mouvement vers la gauche

            update(self) :
                Met à jour les positions et rectangle (hitbox)
                :return :

            move_back(self) :
                Permet de replacer le joueur là où il était avant qu'il entre en collision
                :return :

        Player() :
            Crée le joueur et vérifie si le joueur attaque

            verif_si_mort(self) :
                Vérifie si le joueur est mort ou pas
                :return : (bool) True sinon rien

            attacks_from_player(self) :
                Détecte si le joueur attaque
                :return : True
                sinon None

            attaque_left(self) :
                Attaque gauche du joueur (animation)
                :return :

            attaque_right(self) :
                Attaque droite du joueur (animation)
                :return :

            attaque_up(self) :
                Attaque haut du joueur (animation)
                :return :

            attaque_down(self) :
                Attaque bas du joueur (animation)
                :return :

        Monster() :
            Crée les entités qui attaquent le joueur (PVE)
            Cette entité possède une méthode de suivi du joueur

            verif_si_mort(self) :
                Vérifie si le joueur est mort ou pas
                :return : (bool) True sinon rien

            mob_spawn(self) :
                Permet de téléporter le monstre à son spawn
                :return :

            load_mob_spawn(self, tmx_data) :
                Charge le point de spawn du monstre
                :param tmx_data :
                :return :

            following(self, player) :
                Le monstre pourchasse le joueur
                :return :

            attaque_player(self, player) :
                Vérifie si le joueur se trouve en haut, bas, gauche, droite
                pour changer l'animation
                :param player :
                :return :

        NPC() :
            Personnage non joueur et passif à Player
            Suit un chemin précis sur la map ou peut ne pas bouger selon le choix de
            la configuration de la map et du code

            move(self) :
                Permet au npc d'aller d'un point A à un point B défini sur la map
                :return :

            teleport_point(self) :
                Définit le point de spawn du NPC
                :return :

            load_point(self, tmx_data) :
                Récupère les points de passage du pnj
                :return :

    ----------------------------------------------------------------------------------------------------

    animation.py

    Fait les animations pour chaque entité (sauf Boss)

        -import :
            pygame

    class :
        AnimateSprite() :
            Prend sur le sprite sur une coordonnée y choisie dans le constructeur
            Cela peut être adapté pour une image voulue car certaines sont différentes des autres
            alors on modifie le x, la taille pour obtenir l'image voulue comme les attaques du chevalier
            ou du mage qui sont différentes de celles de l'archer

            ajouter_les_attaques_en_fonction_du_personnage_choisi(self) :
                Charge les animations d'attaque et les ajoute à self animation car AUCUN
                n'attaque de la même façon sur le sprite

            change_animation(self, name) :
                Change l'animation de l'entité en fonction de son déplacement
                :param name : nom de l'animation
                :return :

            get_images(self, y, distance, taille_image, size_x, size_y) :
                Parcours l'image qui contient les différents déplacements du joueur et les stocke dans un tableau d'images
                :param y : coordonnées y de l'image
                :param distance : nombres d'images
                :param taille_image :
                :param size_x :
                :param size_y :
                :return : liste d'images

            get_image(self, x, y, size_x, size_y) :
                Prend l'image sur les coordonnées en x et y de l'image (sprite) et la taille
                :param x : coordonnées x de l'image
                :param y : coordonnées y de l'image
                :param size_x : taille en x
                :param size_y : taille en y

            get_image_attack(self, x, y, size_x, size_y) :
                Prend l'image sur les coordonnées en x et y de l'image (sprite) et la taille pour les animations
                d'attaque
                :param x : coordonnées x de l'image
                :param y : coordonnées y de l'image
                :param size_x : taille en x
                :param size_y : taille en y

            get_images_attack(self, y, distance, taille_image, size_x, size_y) :
                Parcours l'image qui contient les différentes attaques du joueur et les stocke
                dans un tableau images
                :param y : coordonnées y de l'image
                :param distance : nombres d'images
                :param taille_image :
                :param size_x :
                :param size_y :
                :return : liste d'images

    ----------------------------------------------------------------------------------------------------

    dialog.py

    Fait les dialogues des pnj, s'active lorsque le joueur est à proximité et appuie sur espace
    et fait aussi l'interface qui affiche la vie du joueur.

        -import :
            pygame

    class :
        DialogBox() :

            execute(self, dialogo=[]) :
                Vérifie si on est en train de lire, si oui on passe au prochain texte si il existe
                Sinon on lance la boîte de dialogue
                :param dialogo : texte dit par le pnj
                :return :

            render(self, screen) :
                Affiche le texte lettre par lettre dans la boîte de dialogue
                :param screen : écran du jeu
                :return :

            next_text(self) :
                Passe d'une phrase à une autre si c'est possible
                :return :

    Merci d'avoir lu cette documentation
    """
